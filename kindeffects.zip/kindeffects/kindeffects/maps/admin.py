from django.contrib import admin
from .models import Map,Code
# Register your models here.
admin.site.register(Map)
admin.site.register(Code)